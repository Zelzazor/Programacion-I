public class Persona{
    String nombre;
    String apellido;
    int edad;
    char sexo;

    public void comer(){
        System.out.println("Comiendo");
    }

    public void dormir(){
        System.out.println("Durmiendo");
    }

    public void caminar(){
        System.out.println("Caminando");
    }

    public void correr(){
        System.out.println("Corriendo");
    }

}