public class Calculadora{
    public double sumar(double x, double y){
        return x + y;
    }
    public double sumar(double x, double y, double z){
        return x + y + z;
    }
    public double sumar(double x, double y, double z, double w){
        return x + y + z + w;
    }
    public double restar(double x, double y){
        return x - y;
    }
    public double restar(double x, double y, double z){
        return x - y - z;
    }
    public double restar(double x, double y, double z, double w){
        return x - y - z - w;
    }
    public double multiplicar(double x, double y){
        return x * y;
    }
    public double multiplicar(double x, double y, double z){
        return x * y * z;
    }
    public double multiplicar(double x, double y, double z, double w){
        return x * y * z * w;
    }
    public double dividir(double x, double y){
        return x / y;
    }
}