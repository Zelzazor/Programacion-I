import javax.swing.*;
import java.awt.*;

class InterfazCalculadora{

    JButton[] buttons = new JButton[24];
    JPanel panel = new JPanel(new GridLayout(6,4,12,12));
    Font fuente = new Font("Consolas", 1, 48);
    JFrame frame = new JFrame("Calculadora");

    public InterfazCalculadora(){
        
        crearFrame();
        crearCajaDeTexto();
        crearBotones(buttons);
        InsertarBotones(buttons, panel);
        insertarPanel(panel);
        
    }

    private void insertarPanel(Container C) {
        C.setSize(200, 200);
        frame.getContentPane().add(C, BorderLayout.CENTER);
    }

    private void crearFrame() {
        frame.setVisible(true);
        frame.setSize(300, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void InsertarBotones(AbstractButton[] botones, Container C){
        for (int i = 0; i < botones.length; i++){

            C.add(botones[i]);

        }
    }

    private void crearBotones(AbstractButton[] botones) {

        for (int i = 0; i < botones.length; i++) {

            botones[i] = new JButton();

        }

        

        nombreBotones(buttons);

    }

    private void nombreBotones(AbstractButton[] botones){

        botones[21].setText("0");
        botones[16].setText("1");
        botones[17].setText("2");
        botones[18].setText("3");
        botones[14].setText("4");
        botones[13].setText("5");
        botones[12].setText("6");
        botones[8].setText("7");
        botones[9].setText("8");
        botones[10].setText("9");
        botones[7].setText("÷");
        botones[11].setText("*");
        botones[15].setText("-");
        botones[19].setText("+");
        botones[23].setText("=");
        botones[22].setText(".");
        botones[20].setText("±");
        botones[6].setText("←");
        botones[5].setText("C");
        botones[4].setText("CE");
        botones[3].setText("1/x");
        botones[2].setText("x²");
        botones[1].setText("√");
        botones[0].setText("%");

    }
    

    private void crearCajaDeTexto(){

        JTextField cajaDeTexto = new JTextField(30);
        cajaDeTexto.setFont(fuente);
        cajaDeTexto.setHorizontalAlignment(SwingConstants.RIGHT); 
        cajaDeTexto.setPreferredSize(new Dimension(200, 50));
        cajaDeTexto.setText("0");
        cajaDeTexto.setEditable(false);
        frame.add(cajaDeTexto, BorderLayout.NORTH);

    }
}