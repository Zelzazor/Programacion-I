import javax.swing.*;

class InterfazAjedrezT {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            public void run(){

                new InterfazAjedrez();

            }

        });
    
    }
}